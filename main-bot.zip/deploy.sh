#!/bin/bash
# ============================================================
#  ДЕПЛОЙ — обновляет код на всех воркерах одной командой
#  Запуск: bash deploy.sh
# ============================================================

WORKER_IPS=(
    "3.89.180.47"
    "3.95.18.171"
    "54.221.63.241"
    "54.236.212.62"
)

SSH_USER="xheejdgwhd"
BOT_DIR="~/bot"
SSH_KEY="~/.ssh/id_rsa"   # путь к твоему SSH ключу

# Файлы которые копируем на каждый воркер
FILES=(
    "activation.py"
    "http_activator.py"
    "browser.py"
    "config.py"
    "logger.py"
    "state.py"
    "worker.py"
)

echo "=== Деплой на ${#WORKER_IPS[@]} воркеров ==="

for i in "${!WORKER_IPS[@]}"; do
    IP="${WORKER_IPS[$i]}"
    ACC_ID=$((i + 1))
    echo ""
    echo "--- Воркер $ACC_ID ($IP) ---"

    # Копируем файлы
    for f in "${FILES[@]}"; do
        scp -i "$SSH_KEY" -o StrictHostKeyChecking=no \
            "$f" "${SSH_USER}@${IP}:${BOT_DIR}/" 2>/dev/null
    done

    # Перезапускаем воркер
    ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no \
        "${SSH_USER}@${IP}" \
        "pkill -f worker.py 2>/dev/null; sleep 1; \
         cd ${BOT_DIR} && \
         ACC_ID=${ACC_ID} WORKER_SECRET=secret123 WORKER_PORT=8080 \
         nohup python3 -u worker.py > worker.log 2>&1 &" 2>/dev/null

    echo "✅ Воркер $ACC_ID перезапущен"
done

echo ""
echo "=== Готово ==="
