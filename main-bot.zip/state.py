# ============================================================
#  ОБЩЕЕ СОСТОЯНИЕ — импортируется всеми модулями
# ============================================================
import threading

# Браузеры
drivers      = []
drivers_lock = threading.Lock()

# Промо
promo_pool      = []
used_promos     = set()
promo_pool_lock = threading.Lock()
last_promo_time = 0
distribute_lock = threading.Lock()

import queue
irc_join_queue = queue.Queue()  # динамический JOIN каналов
