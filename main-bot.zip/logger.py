# ============================================================
#  ЛОГИРОВАНИЕ
# ============================================================
import datetime


def get_time() -> str:
    return (datetime.datetime.utcnow() + datetime.timedelta(hours=3)).strftime('%H:%M:%S')


def log(acc_id, msg: str):
    prefix = f"[{get_time()}]" + (f" [Акк {acc_id}]" if acc_id else "")
    print(f"{prefix} {msg}")
