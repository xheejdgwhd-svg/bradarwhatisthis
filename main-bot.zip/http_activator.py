# ============================================================
#  HTTP АКТИВАТОР v2.1
#  Сессия строится ОДИН РАЗ при старте браузера.
#  В hot-path только обязательный GET за свежими токенами.
#  Скорость: ~0.3-0.8 сек вместо 4-13 сек на Selenium
# ============================================================
import requests
import threading
import time
from urllib.parse import unquote

from config import TARGET_URL
from logger import log

ACTIVATE_PAGE = "https://donatov.net/profile/dcard/activate"
ACTIVATE_URL  = "https://donatov.net/profile/dcard/activate/request"

_sessions      = {}   # {acc_id: requests.Session}
_sessions_lock = threading.Lock()

# Кеш XSRF токенов — обновляется в фоне, не блокирует hot-path
# {acc_id: {"xsrf": str, "ts": float}}
_xsrf_cache      = {}
_xsrf_cache_lock = threading.Lock()
XSRF_TTL         = 25   # секунд — обновляем заранее (сервер обновляет при каждом GET)
XSRF_REFRESH_INTERVAL = 20  # фоновый поток обновляет каждые 20с


# ============================================================
#  ИНИЦИАЛИЗАЦИЯ СЕССИИ — вызывать ОДИН РАЗ после старта браузера
# ============================================================
def init_session(driver, acc_id: int) -> bool:
    """
    Строит requests.Session из куков Chrome.
    Вызывается один раз: после setup_browser() в browser.py.
    Не вызывать в hot-path активации.
    """
    try:
        cookies = driver.get_cookies()
        if not cookies:
            log(acc_id, "⚠️ HTTP init: куки пустые")
            return False

        session = requests.Session()
        session.headers.update({
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                          "(KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
            "Accept":     "application/json, text/plain, */*",
            "Referer":    ACTIVATE_PAGE,
            "Origin":     "https://donatov.net",
            "sec-ch-ua":          '"Not:A-Brand";v="99", "Google Chrome";v="145"',
            "sec-ch-ua-mobile":   "?0",
            "sec-ch-ua-platform": '"Linux"',
        })

        for c in cookies:
            session.cookies.set(
                c["name"], c["value"],
                domain=c.get("domain", ".donatov.net"),
                path=c.get("path", "/"),
            )

        # Проверяем что есть remember_web — без него сессия бесполезна
        remember = any("remember_web" in c.get("name", "") for c in cookies)
        if not remember:
            log(acc_id, "⚠️ HTTP init: нет remember_web куки — Selenium fallback")
            return False

        with _sessions_lock:
            _sessions[acc_id] = session

        log(acc_id, "✅ HTTP сессия инициализирована")
        return True

    except Exception as e:
        log(acc_id, f"⚠️ HTTP init_session: {e}")
        return False


def drop_session(acc_id: int):
    """Удаляет сессию — вызывать при остановке браузера."""
    with _sessions_lock:
        _sessions.pop(acc_id, None)


def has_session(acc_id: int) -> bool:
    with _sessions_lock:
        return acc_id in _sessions


# ============================================================
#  ВНУТРЕННИЕ ХЕЛПЕРЫ
# ============================================================
def _get_xsrf(session: requests.Session) -> str:
    """URL-декодирует XSRF токен из куков сессии."""
    token = (session.cookies.get("XSRF-TOKEN", domain=".donatov.net")
             or session.cookies.get("XSRF-TOKEN", domain="donatov.net")
             or session.cookies.get("XSRF-TOKEN")
             or "")
    return unquote(token)


def _fetch_fresh_tokens(session: requests.Session, acc_id: int) -> str:
    """
    Обязательный GET страницы активации — сервер возвращает
    свежие donat + XSRF-TOKEN в Set-Cookie.
    Возвращает свежий decoded XSRF или '' при ошибке.
    """
    try:
        r = session.get(ACTIVATE_PAGE, timeout=1.2, allow_redirects=True)
        xsrf = _get_xsrf(session)
        # Логируем Set-Cookie чтобы видеть какие токены сервер вернул
        set_cookie = r.headers.get("Set-Cookie", "")
        cookies_received = [c.split("=")[0].strip() for c in set_cookie.split(";") if "=" in c]
        if xsrf:
            log(acc_id, f"🔄 Токены обновлены | Set-Cookie: {cookies_received} | XSRF: {xsrf[:20]}...")
        else:
            log(acc_id, f"⚠️ GET не вернул XSRF | Set-Cookie: {set_cookie[:150]}")
        return xsrf
    except Exception as e:
        log(acc_id, f"⚠️ _fetch_fresh_tokens: {e}")
        return ""


# ============================================================
#  АКТИВАЦИЯ — HOT PATH
#  Только один запрос: сразу "activate" без предварительного "check".
#  Причина: "check" вызывал rate-limit ("Пожалуйста, попробуйте позже")
#  когда 4 воркера слали запросы в течение ~150мс.
#  Один запрос = вдвое меньше нагрузки + укладываемся в 2с.
# ============================================================
def activate_http(driver, acc_id: int, code: str) -> dict:
    """
    Активирует промокод через HTTP (один POST activate).
    Возвращает {"success": bool, "message": str, "status_code": int,
                "elapsed": float, "dump_records": list}
    """
    t0 = time.time()

    # ── Сессия ──────────────────────────────────────────────
    with _sessions_lock:
        session = _sessions.get(acc_id)

    if not session:
        log(acc_id, "HTTP: сессия не найдена — инициализирую...")
        if not init_session(driver, acc_id):
            return {"success": False, "message": "Нет сессии",
                    "status_code": 0, "elapsed": round(time.time()-t0, 2), "dump_records": []}
        with _sessions_lock:
            session = _sessions.get(acc_id)

    # ── GET страницы — свежие XSRF + donat куки ─────────────
    # Таймаут 1.2с: если сервер не отвечает за это время — уже опаздываем
    xsrf = _fetch_fresh_tokens(session, acc_id)
    if not xsrf:
        return {"success": False, "message": "Нет XSRF токена",
                "status_code": 0, "elapsed": round(time.time()-t0, 2), "dump_records": []}

    headers = {
        "Content-Type": "application/json",
        "X-XSRF-TOKEN": xsrf,
    }

    try:
        # ── Единственный POST: сразу activate ───────────────
        r = session.post(
            ACTIVATE_URL,
            json={"action": "activate", "code": code},
            headers=headers,
            timeout=1.5,   # жёсткий таймаут — в 2с должны уложиться вместе с GET
        )
        elapsed = round(time.time() - t0, 2)
        resp_headers = {
            "Content-Type":  r.headers.get("Content-Type", ""),
            "Set-Cookie":    r.headers.get("Set-Cookie", ""),
            "X-RateLimit-Remaining": r.headers.get("X-RateLimit-Remaining", ""),
            "Retry-After":   r.headers.get("Retry-After", ""),
        }
        # Убираем пустые
        resp_headers = {k: v for k, v in resp_headers.items() if v}
        log(acc_id, f"HTTP activate → {r.status_code} | body: {r.text[:200]} | headers: {resp_headers} ({elapsed}с)")

        # ── 419: XSRF истёк — один повтор ───────────────────
        if r.status_code == 419:
            log(acc_id, "419 XSRF — обновляю и повторяю...")
            xsrf = _fetch_fresh_tokens(session, acc_id)
            if not xsrf:
                return {"success": False, "message": "419 + нет XSRF",
                        "status_code": 419, "elapsed": round(time.time()-t0, 2), "dump_records": []}
            headers["X-XSRF-TOKEN"] = xsrf
            r = session.post(
                ACTIVATE_URL,
                json={"action": "activate", "code": code},
                headers=headers,
                timeout=1.5,
            )
            elapsed = round(time.time() - t0, 2)
            resp_headers_r = {k: v for k, v in {
                "Set-Cookie": r.headers.get("Set-Cookie", ""),
                "X-RateLimit-Remaining": r.headers.get("X-RateLimit-Remaining", ""),
                "Retry-After": r.headers.get("Retry-After", ""),
            }.items() if v}
            log(acc_id, f"HTTP activate retry → {r.status_code} | body: {r.text[:200]} | headers: {resp_headers_r} ({elapsed}с)")

        resp_text = r.text.lower()

        # ── Классификация ответа ─────────────────────────────
        # Слова явного успеха
        SUCCESS_KW = ["успешно", "активирован", "получили", "зачислен", "добавлен", "success"]
        # Слова явной ошибки логики (не технической)
        LOGIC_FAIL_KW = [
            "не найден", "not found", "invalid", "недоступен",
            "already", "used", "активирован ранее", "уже использован",
            "истёк", "expired",
        ]
        # Rate-limit / технические ошибки → Selenium fallback
        TECH_FAIL_KW = ["попробуйте позже", "too many", "rate", "временно"]

        has_success  = any(w in resp_text for w in SUCCESS_KW)
        has_logic_fail = any(w in resp_text for w in LOGIC_FAIL_KW)
        has_tech_fail  = any(w in resp_text for w in TECH_FAIL_KW)

        if r.status_code == 200 and not has_logic_fail and not has_tech_fail:
            success = True
        elif r.status_code == 400:
            # Мусорный / невалидный код
            return {"success": False, "message": f"400: {r.text[:80]}",
                    "status_code": 400, "elapsed": elapsed, "dump_records": _dump(code, r)}
        elif r.status_code == 404 or has_logic_fail:
            # Код не найден / уже использован
            return {"success": False, "message": f"not_found: {r.text[:80]}",
                    "status_code": r.status_code or 404, "elapsed": elapsed, "dump_records": _dump(code, r)}
        elif has_tech_fail:
            # Rate-limit — пусть worker уйдёт в Selenium
            log(acc_id, f"HTTP rate-limit: '{r.text[:80]}' → Selenium fallback")
            return {"success": False, "message": f"rate_limit: {r.text[:80]}",
                    "status_code": 429, "elapsed": elapsed, "dump_records": _dump(code, r)}
        else:
            success = False

        return {
            "success":      success,
            "message":      r.text[:200],
            "status_code":  r.status_code,
            "elapsed":      elapsed,
            "dump_records": _dump(code, r),
        }

    except requests.Timeout:
        elapsed = round(time.time() - t0, 2)
        log(acc_id, f"HTTP Timeout после {elapsed}с → Selenium fallback")
        return {"success": False, "message": "Timeout", "status_code": 0,
                "elapsed": elapsed, "dump_records": []}
    except Exception as e:
        return {"success": False, "message": str(e)[:100], "status_code": 0,
                "elapsed": round(time.time()-t0, 2), "dump_records": []}


def _dump(code: str, r) -> list:
    """Формирует dump_records для одного activate запроса."""
    try:    body = r.json()
    except: body = r.text
    return [{
        "url":         ACTIVATE_URL,
        "method":      "POST",
        "req_body":    {"action": "activate", "code": code},
        "resp_status": r.status_code,
        "resp_body":   body,
    }]
