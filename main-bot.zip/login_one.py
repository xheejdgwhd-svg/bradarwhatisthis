import os, time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

BASE = f"/home/{os.getenv('USER')}/bot/farm"

i = 1  # ← МЕНЯЙ НА НУЖНЫЙ НОМЕР АККАУНТА

email = input("Email: ").strip()
options = Options()
user_dir = os.path.join(BASE, f"acc_{i}")
os.makedirs(user_dir, exist_ok=True)
options.add_argument(f"--user-data-dir={user_dir}")
options.add_argument("--no-sandbox")
options.add_argument("--disable-dev-shm-usage")
options.add_argument("--headless=new")
driver = webdriver.Chrome(options=options)
driver.get("https://donatov.net/login")
time.sleep(3)
WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "email")))
driver.find_element(By.ID, "email").send_keys(email)
btn = driver.find_element(By.ID, "loginSubmit")
driver.execute_script("arguments[0].click();", btn)
time.sleep(3)
print(f"Письмо отправлено на {email}")
magic_link = input("Вставь ссылку из письма: ").strip()
driver.get(magic_link)
time.sleep(4)
print(f"URL: {driver.current_url}")
if "login" not in driver.current_url and "auth" not in driver.current_url:
    print(f"✅ Аккаунт {i} залогинен")
else:
    print(f"❌ Что-то пошло не так")
driver.quit()
