# ============================================================
#  MAIN — точка входа
# ============================================================
import os
import time
import threading
import signal

from config      import ACCOUNTS_COUNT
from config      import load_config, save_config
from logger      import log
from browser        import start_all_browsers, stop_all_browsers, browser_watchdog
from stream_checker import stream_worker, is_stream_live, get_stream_status
from distributor import distribute_promos
from irc         import listen_twitch
from telegram_bot import tg, tg_polling_worker
from log_receiver import start_log_receiver


def start_browsers_fn():
    from telegram_bot import tg_send, main_keyboard
    from distributor import restart_all_workers
    from state import drivers
    start_all_browsers()
    # restart вместо start — гарантированно убивает старый браузер и поднимает свежий
    threading.Thread(target=restart_all_workers, daemon=True).start()
    tg_send(f"▶️ Браузеры запущены\n👥 Аккаунтов: {len(drivers)}/{ACCOUNTS_COUNT}", main_keyboard())


def stop_browsers_fn():
    from telegram_bot import tg_send, main_keyboard
    from distributor import stop_all_workers
    stop_all_browsers()
    threading.Thread(target=stop_all_workers, daemon=True).start()
    tg_send("⏹ Браузеры остановлены", main_keyboard())


def restart_browsers_fn():
    from telegram_bot import tg_send, main_keyboard
    from distributor import restart_all_workers
    tg_send("🔄 Перезапускаю браузеры...", main_keyboard())
    stop_all_browsers()
    time.sleep(2)
    start_all_browsers()
    threading.Thread(target=restart_all_workers, daemon=True).start()





def main():
    os.system('pkill -f chrome 2>/dev/null; pkill -f chromedriver 2>/dev/null')
    time.sleep(2)

    # Загружаем конфиг
    cfg = load_config()
    bot_state = {
        "bot_mode":         cfg["mode"],
        "browsers_on":      cfg["browsers_on"],
        "channels":         cfg.get("channels", ["t2x2"]),
        "waiting_for":      None,
        "start_browsers_fn":   start_browsers_fn,
        "stop_browsers_fn":    stop_browsers_fn,
        "restart_browsers_fn": restart_browsers_fn,
        "save_config_fn":      save_config,
    }

    log(None, f"Конфиг: mode={bot_state['bot_mode']}, browsers_on={bot_state['browsers_on']}")

    # Решаем запускать ли браузеры
    if bot_state["bot_mode"] == "passive":
        log(None, "Режим: пассивный — запускаю браузеры")
        start_all_browsers()
    elif bot_state["bot_mode"] == "manual" and bot_state["browsers_on"]:
        log(None, "Режим: по кнопке (ВКЛ) — запускаю браузеры")
        start_all_browsers()
    elif bot_state["bot_mode"] == "schedule":
        channels_cfg = bot_state.get("channels", {"t2x2": "emoji"})
        ch_list      = list(channels_cfg.keys()) if isinstance(channels_cfg, dict) else channels_cfg
        log(None, "Режим: стрим — проверяю статус стримеров...")
        statuses  = {ch: is_stream_live(ch) for ch in ch_list}
        live_list = [ch for ch, s in statuses.items() if s]
        log(None, f"Статусы: {statuses}")
        if live_list:
            log(None, f"Стримят: {live_list} — запускаю браузеры")
            start_all_browsers()
        else:
            log(None, "Все офлайн — браузеры не запускаем, ждём стрима")
    else:
        log(None, f"Режим: по кнопке (ВЫКЛ) — браузеры не запускаем")

    from state import drivers
    if drivers:
        log(None, f"Готово: {len(drivers)}/{ACCOUNTS_COUNT} аккаунтов")
    else:
        log(None, "Браузеры не запущены — ждём расписания или команды из TG")

    # Запускаем LogReceiver
    start_log_receiver()

    # Запускаем потоки
    threading.Thread(target=browser_watchdog, daemon=True, name="Watchdog").start()
    threading.Thread(target=stream_worker, args=(bot_state, start_browsers_fn, stop_browsers_fn), daemon=True, name="StreamChecker").start()
    threading.Thread(target=tg_polling_worker, args=(bot_state,), daemon=True, name="TGPolling").start()

    # Graceful shutdown
    def _shutdown(sig, frame):
        log(None, "SIGINT/SIGTERM — завершение...")
        stop_all_browsers()
        os._exit(0)
    signal.signal(signal.SIGINT,  _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    # IRC слушает вечно
    listen_twitch(
        get_channels_fn=lambda: bot_state["channels"],
        distribute_fn=distribute_promos,
        tg_fn=tg
    )


if __name__ == "__main__":
    main()
