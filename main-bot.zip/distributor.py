"""
DISTRIBUTOR — заменяет distribute_promos на controller.
Шлёт промокоды воркерам с небольшими задержками (антибот).

Импортируется в activation.py вместо старой distribute_promos.
"""
import json
import time
import threading
import urllib.request
import urllib.error
import os

from logger import log

# ── КОНФИГ ВОРКЕРОВ ────────────────────────────────────────
# Заполни IP каждого VPS
WORKERS = [
    {"id": 1, "url": "http://3.89.180.47:8080"},   # main-bot (worker-1)
    {"id": 2, "url": "http://3.95.18.171:8080"},    # worker-1
    {"id": 3, "url": "http://54.221.63.241:8080"},  # worker-2
    {"id": 4, "url": "http://54.236.212.62:8080"},   # worker-3
]
WORKER_SECRET = os.getenv("WORKER_SECRET", "secret123")
import random

STAGGER_MS_MIN = 120
STAGGER_MS_MAX = 260


def _send_to_worker(worker: dict, code: str, irc_time: float = None):
    """Отправляет код одному воркеру."""
    t0 = time.time()
    if irc_time:
        log(None, f"[W{worker['id']}] ⏱ IRC→worker: {round(t0 - irc_time, 3)}с")

    # Ждём пока браузер воркера будет готов (до 60 сек)
    deadline = time.time() + 60
    while time.time() < deadline:
        try:
            req  = urllib.request.Request(f"{worker['url']}/ping")
            resp = urllib.request.urlopen(req, timeout=3)
            data = json.loads(resp.read().decode())
            if data.get("browser"):
                break
        except Exception:
            pass
        time.sleep(2)
    else:
        log(None, f"[W{worker['id']}] ⏱ Браузер не готов за 60с — пропуск")
        return

    try:
        body = json.dumps({"code": code}).encode()
        req  = urllib.request.Request(
            f"{worker['url']}/activate",
            data=body,
            headers={
                "Content-Type":    "application/json",
                "X-Worker-Secret": WORKER_SECRET,
            },
            method="POST",
        )
        resp     = urllib.request.urlopen(req, timeout=15)
        result   = json.loads(resp.read().decode())
        elapsed  = round(time.time() - t0, 2)
        success  = result.get("success", False)
        method   = result.get("method", "?")
        log(None, f"[W{worker['id']}] {'✅' if success else '❌'} {method} {elapsed}с | {code}")

    except urllib.error.HTTPError as e:
        log(None, f"[W{worker['id']}] HTTP {e.code}: {e.read().decode()[:100]}")
    except Exception as e:
        log(None, f"[W{worker['id']}] Ошибка: {str(e)[:100]}")


def distribute_promos(promos: list, irc_time: float = None):
    """
    Раздаёт промокоды воркерам с задержкой STAGGER_MS между каждым.
    Выглядит как разные люди, не как бот.
    """
    if not promos:
        return

    count = min(len(promos), len(WORKERS))
    log(None, f"Раздача {count}/{len(promos)} кодов воркерам (stagger={STAGGER_MS_MIN}-{STAGGER_MS_MAX}мс рандом)")

    for i in range(count):
        worker = WORKERS[i]
        code   = promos[i]
        # Каждый воркер независимо рандомит 0-150мс
        # W1 тоже может стартовать не мгновенно — убирает bot-pattern
        # Максимальная задержка 150мс — при 10с окне это приемлемо
        delay  = random.randint(0, 150) / 1000.0

        def _task(w=worker, c=code, d=delay, t=irc_time):
            if d > 0:
                time.sleep(d)
            _send_to_worker(w, c, t)

        threading.Thread(target=_task, daemon=True).start()


def get_workers_status() -> list:
    """Проверяет статус всех воркеров — для TG статуса."""
    results = []
    def _check(w):
        try:
            # Пробуем /status
            req  = urllib.request.Request(
                f"{w['url']}/status",
                headers={"X-Worker-Secret": WORKER_SECRET},
            )
            resp = urllib.request.urlopen(req, timeout=5)
            data = json.loads(resp.read().decode())
            if "error" not in data:
                results.append({"id": w["id"], "ok": True, "browser": True, "url": w["url"], **data})
                return
        except Exception:
            pass
        # Fallback — /ping
        try:
            req  = urllib.request.Request(f"{w['url']}/ping")
            resp = urllib.request.urlopen(req, timeout=5)
            data = json.loads(resp.read().decode())
            results.append({"id": w["id"], "ok": True, "browser": data.get("ok", False), "url": w["url"]})
        except Exception as e:
            results.append({"id": w["id"], "ok": False, "error": str(e)[:50], "url": w["url"]})

    threads = [threading.Thread(target=_check, args=(w,), daemon=True) for w in WORKERS]
    for t in threads: t.start()
    for t in threads: t.join(timeout=6)
    return sorted(results, key=lambda r: r["id"])


def _worker_cmd(url: str, path: str) -> bool:
    """Отправляет команду воркеру. Возвращает True если успешно."""
    try:
        req  = urllib.request.Request(
            f"{url}{path}",
            data=b"{}",
            headers={"Content-Type": "application/json", "X-Worker-Secret": WORKER_SECRET},
            method="POST"
        )
        urllib.request.urlopen(req, timeout=30)
        return True
    except Exception:
        return False


def start_all_workers() -> dict:
    """Запускает браузеры на всех воркерах. Возвращает {acc_id: ok}."""
    results = {}
    lock = threading.Lock()
    def _start(w):
        ok = _worker_cmd(w["url"], "/start_browser")
        with lock:
            results[w["id"]] = ok
    threads = [threading.Thread(target=_start, args=(w,), daemon=True) for w in WORKERS]
    for t in threads: t.start()
    for t in threads: t.join(timeout=35)
    return results


def stop_all_workers() -> dict:
    """Останавливает браузеры на всех воркерах. Возвращает {acc_id: ok}."""
    results = {}
    lock = threading.Lock()
    def _stop(w):
        ok = _worker_cmd(w["url"], "/stop_browser")
        with lock:
            results[w["id"]] = ok
    threads = [threading.Thread(target=_stop, args=(w,), daemon=True) for w in WORKERS]
    for t in threads: t.start()
    for t in threads: t.join(timeout=35)
    return results


def restart_all_workers() -> dict:
    """Перезапускает браузеры на всех воркерах."""
    results = {}
    lock = threading.Lock()
    def _restart(w):
        ok = _worker_cmd(w["url"], "/restart_browser")
        with lock:
            results[w["id"]] = ok
    threads = [threading.Thread(target=_restart, args=(w,), daemon=True) for w in WORKERS]
    for t in threads: t.start()
    for t in threads: t.join(timeout=35)
    return results
