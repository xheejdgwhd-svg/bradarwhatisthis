# ============================================================
#  STREAM CHECKER — следит за статусом стрима через Twitch API
# ============================================================
import urllib.request
import urllib.parse
import json
import time
import threading

from config import TWITCH_CLIENT_ID, TWITCH_CLIENT_SECRET
from logger import log

_token            = None
_token_expiry     = 0
_token_lock       = threading.Lock()
_stream_live      = False   # текущий известный статус
_last_known_state = None    # синхронизация с TG callback (True/False/None)


def _get_token() -> str:
    """Получает app access token от Twitch. Обновляет за 5 мин до истечения."""
    global _token, _token_expiry
    with _token_lock:
        if _token and time.time() < _token_expiry - 300:
            return _token
        url  = "https://id.twitch.tv/oauth2/token"
        data = urllib.parse.urlencode({
            "client_id":     TWITCH_CLIENT_ID,
            "client_secret": TWITCH_CLIENT_SECRET,
            "grant_type":    "client_credentials",
        }).encode()
        resp   = urllib.request.urlopen(url, data=data, timeout=10)
        result = json.loads(resp.read().decode())
        _token        = result["access_token"]
        _token_expiry = time.time() + result.get("expires_in", 3600 * 24 * 60)
        return _token


def is_stream_live(channel: str) -> bool:
    """Возвращает True если стример сейчас онлайн."""
    try:
        token = _get_token()
        url   = f"https://api.twitch.tv/helix/streams?user_login={channel}"
        req   = urllib.request.Request(url, headers={
            "Client-ID":     TWITCH_CLIENT_ID,
            "Authorization": f"Bearer {token}",
        })
        resp = urllib.request.urlopen(req, timeout=10)
        data = json.loads(resp.read().decode())
        return len(data.get("data", [])) > 0
    except Exception as e:
        log(None, f"[StreamChecker] Ошибка проверки стрима: {e}")
        return False


def set_known_state(state):
    """Вызывается из TG callback чтобы синхронизировать stream_worker."""
    global _last_known_state
    _last_known_state = state


def stream_worker(bot_state: dict, start_fn, stop_fn):
    """
    Фоновый поток — проверяет статус стримов каждые 60 сек.
    Логика:
    - Браузеры запускаются если хотя бы 1 стример онлайн И браузеры ещё не запущены
    - Браузеры останавливаются только если ВСЕ стримеры офлайн
    - При добавлении нового стримера: проверяет реальное состояние браузеров
    """
    global _stream_live, _last_known_state
    log(None, "StreamChecker запущен...")

    while True:
        time.sleep(60)

        if bot_state["bot_mode"] != "schedule":
            _last_known_state = None
            continue

        # Получаем список каналов (поддерживаем dict и list)
        channels_cfg = bot_state.get("channels", {"t2x2": "emoji"})
        ch_list = list(channels_cfg.keys()) if isinstance(channels_cfg, dict) else list(channels_cfg)

        # Проверяем статус каждого стримера отдельно
        statuses = {ch: is_stream_live(ch) for ch in ch_list}
        any_live  = any(statuses.values())
        all_dead  = not any_live
        _stream_live = any_live

        live_list = [ch for ch, s in statuses.items() if s]
        log(None, f"StreamChecker: {statuses} → any_live={any_live}")

        from state import drivers, drivers_lock
        with drivers_lock:
            local_running = len(drivers) > 0
        # Считаем браузеры запущенными если хотя бы main-бот готов
        # (воркеры запускаются параллельно через start_all_workers)
        browsers_running = local_running

        if any_live and not browsers_running:
            # Стрим есть, браузеров нет — запускаем
            log(None, f"📡 Стрим онлайн ({', '.join(live_list)}) — запускаю браузеры")
            from telegram_bot import tg_send, main_keyboard
            tg_send(f"📡 <b>Стрим начался!</b> ({', '.join('#'+c for c in live_list)}) — запускаю браузеры", main_keyboard())
            threading.Thread(target=start_fn, daemon=True).start()
            _last_known_state = True

        elif all_dead and browsers_running:
            # Все стримеры офлайн, браузеры работают — останавливаем
            log(None, "📴 Все стримы закончились — останавливаю браузеры")
            from telegram_bot import tg_send, main_keyboard
            tg_send("📴 <b>Все стримы закончились</b> — останавливаю браузеры", main_keyboard())
            threading.Thread(target=stop_fn, daemon=True).start()
            _last_known_state = False

        elif any_live and browsers_running:
            # Всё нормально — стрим идёт, браузеры работают
            _last_known_state = True

        elif all_dead and not browsers_running:
            # Всё офлайн, браузеры выключены — норма
            _last_known_state = False


def get_stream_status(channels) -> dict:
    ch_list = list(channels.keys()) if isinstance(channels, dict) else channels
    result  = {}
    for ch in ch_list:
        result[ch] = is_stream_live(ch)
    return result
