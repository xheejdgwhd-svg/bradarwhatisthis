# ============================================================
#  КОНФИГ
# ============================================================
import json
import os

CONFIG_PATH = "/home/xheejdgwhd/bot/config.json"

DEFAULT_CONFIG = {
    "mode":        "schedule",   # passive | manual | schedule
    "browsers_on": False,
    "channels":    {"t2x2": "emoji"},  # {channel: filter_type} filter: "emoji" | "clean"
}

# Константы бота
BOT_NICK          = 'prodeagle228'
AUTH_TOKEN        = 'oauth:glx18nrosmqcdpp72qjv8tcw0pw025'
ACCOUNTS_COUNT = 1
BASE_PROFILE_PATH = "/home/xheejdgwhd/bot/farm"
TARGET_URL        = "https://donatov.net/profile/dcard/activate"
INPUT_SELECTOR    = "input.form-control[maxlength='26']"
MAX_RETRIES       = 3

TG_TOKEN   = "8730276434:AAFMXHCFUdohnbnQ1CXkcnxoNkMf2trTkzU"
TG_CHAT_ID = "6411412302"

ACCOUNT_EMAILS = {
    1: "xheejdgwhd@gmail.com",
    2: "gommiklsq@gmail.com",
    3: "garamaandmararam@gmail.com",
    4: "tiktokhunted@gmail.com",
    5: "syka830@gmail.com",
    6: "ook235298@gmail.com",
}

TWITCH_CLIENT_ID     = "1yo5w912bxb2ovpyynl201fcbj48s8"
TWITCH_CLIENT_SECRET = "jmj0siv71tz69epj8zx9k93gse44b8"

SEL_ZABRATY  = "div.bonus-activate-variants_item:first-child"
SEL_ACTIVATE = "button.btn.btn-lg.btn-primary"


def load_config() -> dict:
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        for k, v in DEFAULT_CONFIG.items():
            if k not in cfg:
                cfg[k] = v
        # Убираем старые поля расписания если есть
        for old_key in ("schedule_start_h","schedule_start_m","schedule_end_h","schedule_end_m"):
            cfg.pop(old_key, None)
        # Миграция: channels список → словарь
        if isinstance(cfg.get("channels"), list):
            cfg["channels"] = {ch: "emoji" for ch in cfg["channels"]}
        return cfg
    except Exception:
        return dict(DEFAULT_CONFIG)


def save_config(cfg: dict):
    try:
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[CONFIG] Ошибка сохранения: {e}")
